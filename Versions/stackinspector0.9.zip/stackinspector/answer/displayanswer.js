﻿
window.onresize = async function (event) {
      await OnRezizeWindowEventAsync();
};

const defaultCodeHighlightSetting = "gruvbox-dark";
const minWindowWidth = 1040;



async function AddCodeHighlightStyleSheetToHeadFromLocalStorageSettingOrDefault() {
    var cssFileSettingFromLocalStorage = await GetCodehighlightCssFromLocalStorage();
    if (cssFileSettingFromLocalStorage == null) {
        cssFileSettingFromLocalStorage = defaultCodeHighlightSetting;
    }
    var styleSheetHref = chrome.extension.getURL("answer/codehighlights/styles/" + cssFileSettingFromLocalStorage + ".css");
    $("<link rel='stylesheet' type='text/css' href='" + styleSheetHref + "'> ").appendTo("head");
}


async function DisplayAnswer(answerModel) {
    await AddCodeHighlightStyleSheetToHeadFromLocalStorageSettingOrDefault();
    var displayableHtml = CreateDisplayableAnswerHtml(answerModel);
    await LoadHtmlIntoRightHandSideOfSearchPage(displayableHtml);
    HighlightCodeBlocks();
    if (ScreenWidthTooSmallForAnswer()) {

        Hide(answerHtmlId);
    }
}

function CreateDisplayableAnswerHtml(answerModel) {

    var html = GetQuestionLinkHtml(answerModel);
    html += "<br/>" + GetDateHtml(answerModel);
    html += "<br/>";
    if (answerModel.isAccepted) {
        html += GetAcceptedAnswerHtml() + "<br/>";
    }

    html += " <br/>"+ GetScoreBadgeHtml(answerModel);


    html += answerModel.answerInHtmlFormat;

    return html;
}

function GetQuestionLinkHtml(answerModel) {
    return "Answer for question: <a style='color:blue; font-weight:bold;' href='" + answerModel.link + "'>"
        + answerModel.question +
        "</a> ";
}

function GetDateHtml(answerModel) {
    var date = answerModel.lastEditedDate == null ? answerModel.creationDate : answerModel.lastEditedDate;
    return "<i style='font-style:italic; color:gray; '>Posted: " + date + "</i> ";
}

function GetScoreBadgeHtml(answerModel) {
    let score = answerModel.score;
    return `<img src="https://img.shields.io/badge/-${score}-blue.svg?label=Answer%20Score&color=F8752E&&style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIwIDEwIDgwIDkwIj48c3R5bGU+LnN0MHtmaWxsOiNiY2JiYmJ9LnN0MXtmaWxsOiNmNDgwMjN9PC9zdHlsZT48cGF0aCBjbGFzcz0ic3QwIiBkPSJNODQuNCA5My44VjcwLjZoNy43djMwLjlIMjIuNlY3MC42aDcuN3YyMy4yeiIvPjxwYXRoIGNsYXNzPSJzdDEiIGQ9Ik0zOC44IDY4LjRsMzcuOCA3LjkgMS42LTcuNi0zNy44LTcuOS0xLjYgNy42em01LTE4bDM1IDE2LjMgMy4yLTctMzUtMTYuNC0zLjIgNy4xem05LjctMTcuMmwyOS43IDI0LjcgNC45LTUuOS0yOS43LTI0LjctNC45IDUuOXptMTkuMi0xOC4zbC02LjIgNC42IDIzIDMxIDYuMi00LjYtMjMtMzF6TTM4IDg2aDM4LjZ2LTcuN0gzOFY4NnoiLz48L3N2Zz4="></img>`;
}

function GetAcceptedAnswerHtml() {
    return " <i style='color:green; width='20px;' height='20px;'> &#10004;</i> <i style='font-style:italic; color:gray; '>Answer accepted by question owner</i>  ";
}

function HighlightCodeBlocks() {
    document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightBlock(block)
    });
}

chrome.extension.onRequest.addListener(function (newSettings, sender, sendResponse) {

    UpdateDisplayedAnswerWidthSetting(newSettings.width);
});

function UpdateDisplayedAnswerWidthSetting(width) {

    document.getElementById(answerHtmlId).style.width = width + "%";
}

async function OnRezizeWindowEventAsync() {
    if (!IsDisplayingAnswer()) {
        return;
    }

    if (ScreenWidthTooSmallForAnswer()) {
        Hide(answerHtmlId);
    }
    else {
        Show(answerHtmlId);
    }

    await ReCalculateAnswerWidthAsync();
}


function ScreenWidthTooSmallForAnswer() {
    var width = $(window).width();
    return width < minWindowWidth;
}

function Hide(htmlId) {
    document.getElementById(htmlId).style.display = "none";
}

function Show(htmlId) {
    document.getElementById(htmlId).style.display = "";
}

function IsDisplayingAnswer() {
    var html = document.getElementById(answerHtmlId);
    return html != null;
}

async function ReCalculateAnswerWidthAsync() {
    var userDefinedTheirOwnWidth = await GetShouldUseCustomWidthSettingFromLocalStorage();
    if (userDefinedTheirOwnWidth) {
        return;
    }

    var autoWidth = GetAutoDetectedWidth();
    UpdateDisplayedAnswerWidthSetting(autoWidth);
}
